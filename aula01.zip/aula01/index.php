<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aula 01 - PHP</title>
</head>
<body>
    <?php
        $idade = 43;

        if($idade >= 18)
        {
            echo ("Você pode ser preso!");
        }
        else
        {
            echo ("Você é um piá.");
        }

        echo '<hr>';
    ?>

    <a href="formulario.php"> Trabalhando com formulario </a>
    
</body>
</html>